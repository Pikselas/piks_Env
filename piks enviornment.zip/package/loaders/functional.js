/*                      NON EDITOR MODE      EDITOR MODE
    editorControl()         true                true
    SetVideoPos()           true                false  
    RunQuickView()          true                true
    StartQuickView()        true                false          
    VideoPosChecker()       true                false
    SetImV()                false               true
    SetQuickView()          false               true
    IndDqVc()               true                false
    DownloadScript()        NOT RESTRICTED      NOT RESTRICTED
    startEdit()             NOT RESTRICTED      NOT RESTRICTED
*/

var timeCheck = 500; //time gap for checking video snf images
var EditorMode = false;//Editor mode is active or not
var DownloadValue = null;//contains download url of script
var isQuickView = false;//if quick view is activated
var QuickViewCounter = 0;//current quick view index
var CurrentViewingID = "";//current view no (used for accessing
                         // multiple views)

document.getElementById("middle").children[0].onplay = editorControl;
//start VideoPositionChecker if not in editor mode 
// starts Quick view if Quick view is true 
// when video is start playing
function editorControl()
{
    if(!EditorMode)
    {
        VideoPosChecker();
        if(isQuickView)
        {
            document.getElementById("middle").children[0].removeAttribute("controls");
            StartQuickView();
        }
    }
}
//in inspection mode set the corresponding video timestamp when a image is clicked
//in editor mode calls setImV
//can't be used when quick view is activated
function SetVideoPos(evnt)
{
    if(!EditorMode && !isQuickView)
    {
    for(i = 0;i<SyncImV["IMAGE_ID"].length;i+=1)
    {
        if(SyncImV["IMAGE_ID"][i] == evnt.target.id)
        {
            document.getElementById("middle").children[0].currentTime = SyncImV["VIDEO_TIME"][i];
            break;
        }
    }
    }
    else
    {
        SetImV(evnt);
    }
}
//Activates - Deactivates Quick view mode
function RunQuickView()
{
    if(isQuickView)
    {
        isQuickView = false;
        document.getElementById("middle").children[0].setAttribute("controls","");
        document.getElementById("BannerTop").children[1].children[7].children[0].innerHTML = "FALSE";
        document.getElementById("middle").children[0].pause();
    }
    else
    {
        isQuickView = true;
        document.getElementById("BannerTop").children[1].children[7].children[0].innerHTML = "TRUE";
        document.getElementById("middle").children[0].pause()
    }
}
//Starts quick view
function StartQuickView()
{
    let Paused = document.getElementById("middle").children[0].paused;
    let QuickViewNo = Number(document.getElementById("BannerTop").children[1].children[5].children[1].innerHTML) - 1;
    if((!EditorMode) && isQuickView && !Paused)
   {
    if(QuickViewCounter < QuickView["FROM-TIME"][QuickViewNo].length)
    {
        document.getElementById("middle").children[0].currentTime = QuickView["FROM-TIME"][QuickViewNo][QuickViewCounter];
        let time = QuickView["TO-TIME"][QuickViewNo][QuickViewCounter]-QuickView["FROM-TIME"][QuickViewNo][QuickViewCounter];
        time = time * 1000;
        QuickViewCounter += 1;
        setTimeout(StartQuickView,time);
    }
    else
    {
        let time = QuickView["TO-TIME"][QuickViewNo][QuickViewCounter]-QuickView["FROM-TIME"][QuickViewNo][QuickViewCounter];
        QuickViewCounter = 0;
        setTimeout(StartQuickView,time);
    }
   }
}
//checks if position is last or not and returns values
//i.e if last position returns position value + 10s
//    else returns current position value + next position value 
function posI(v1,v2)
{
    if(v1 != v2 -1)
    {
        return SyncImV["VIDEO_TIME"][v1+1];
    }
    else
    {
        return SyncImV["VIDEO_TIME"][v1] + 10;
    }
}
//Checks the current video timestamp 
// recursive -> uses timeCheck for time gap between two checking
function VideoPosChecker()
{
    if(!document.getElementById("middle").children[0].paused && !EditorMode)
    {
        let len = SyncImV["IMAGE_ID"].length;
        let CurnT = document.getElementById("middle").children[0].currentTime;
        for(let i =0;i<len;i+=1)
        {
            if((CurnT) >= SyncImV["VIDEO_TIME"][i] && (CurnT) < posI(i,len))
            {
                if(CurrentViewingID != "")
                {
                    document.getElementById(CurrentViewingID).style = "filter:blur(5px);";
                }
                CurrentViewingID = SyncImV["IMAGE_ID"][i];
                document.getElementById(CurrentViewingID).scrollIntoView({behavior:'smooth',block:'center'});
                document.getElementById(SyncImV["IMAGE_ID"][i]).style = "filter:blur(0px);";
                break;
            }
        }
        setTimeout(VideoPosChecker,timeCheck);
    }
}
//sets video timestamp and image in editor mode
function SetImV(evnt)
{
    if(EditorMode)
    {
    let isThere = false;
    let ID = evnt.target.id;
    let len = SyncImV["IMAGE_ID"].length;
    let timeStamp = (document.getElementById("middle").children[0].currentTime);
    let Index = SyncImV["IMAGE_ID"].indexOf(ID);
    SyncImV["IMAGE_ID"].splice(Index,1);
    SyncImV["VIDEO_TIME"].splice(Index,1);
    for(let i = 0;i<len;i+=1)
    {
        if(timeStamp < SyncImV["VIDEO_TIME"][i])
        {
            SyncImV["IMAGE_ID"].splice(i,0,ID);
            SyncImV["VIDEO_TIME"].splice(i,0,timeStamp);
            isThere = true;
            break;
        }
    }
    if(!isThere)
    {
        SyncImV["IMAGE_ID"].push(ID);
        SyncImV["VIDEO_TIME"].push(timeStamp);
    }
    document.getElementById("BannerBottom").children[1].value = ID + '->' +timeStamp;
    }
}
// set s the video time stamp by clicking in the start and end time field
function SetQuickViewTime(evnt)
{ 
    document.getElementById(evnt.target.id).children[0].value = (document.getElementById("middle").children[0].currentTime);
}
//sets the quick view times only in editor mode
function SetQuickView()
{
    if(EditorMode)
    {
    let QuickViewNo = Number(document.getElementById("BannerTop").children[1].children[5].children[1].innerHTML) - 1;
    let start = document.getElementById("BannerTop").children[1].children[3].children[0].value;
    let end = document.getElementById("BannerTop").children[1].children[4].children[0].value;
    QuickView["FROM-TIME"][QuickViewNo].push(Number(start));
    QuickView["TO-TIME"][QuickViewNo].push(Number(end));
    document.getElementById("BannerTop").children[1].children[3].children[0].value = 0;
    document.getElementById("BannerTop").children[1].children[4].children[0].value = 0;
    }
}
function InDqVc(V)
{
    let c = Number(document.getElementById("BannerTop").children[1].children[5].children[1].innerHTML)
    if(V > 0)
    {
        c += 1;
        if(c >= QuickView["FROM-TIME"].length && EditorMode)
        {
         QuickView["FROM-TIME"].push([]);
         QuickView["TO-TIME"].push([]);
        }
        else
        {
            if(c > QuickView["FROM-TIME"].length)
            {
                c = QuickView["FROM-TIME"].length;
            }
        }
    }
    else
    {
        c -= 1;
        if(c < 0)
        {
            c = 0;
        }
    }
    document.getElementById("BannerTop").children[1].children[5].children[1].innerHTML = c;
}
//creates the download link  od the generated script
//removes old link if only a script is generated
function DownloadScript()
{
    let DT = 'Json["DATASCRIPT-NAME"]='+'"'+Json["DATASCRIPT-NAME"]+'"'+
             '\nJson["BANNER-TOP"]='+'"'+Json["BANNER-TOP"]+'"'+
             '\nJson["BANNER-BOTTOM"]='+'"'+Json["BANNER-BOTTOM"]+'"'+
             '\nJson["VIDEO"]='+'"'+Json["VIDEO"]+'"'+
             '\nJson["VIDEO-POSTER"]='+'"'+Json["VIDEO-POSTER"]+'"'+
             '\nJson["IMAGE_id"]='+'"'+Json["IMAGE_id"]+'"'+
             '\nJson["IMAGE"]='+JSON.stringify(Json["IMAGE"])+
             '\nSyncImV["IMAGE_ID"]='+JSON.stringify(SyncImV["IMAGE_ID"])+
             '\nSyncImV["VIDEO_TIME"]='+JSON.stringify(SyncImV["VIDEO_TIME"])+
             '\nQuickView["FROM-TIME"]='+JSON.stringify(QuickView["FROM-TIME"])+
             '\nQuickView["TO-TIME"]='+JSON.stringify(QuickView["TO-TIME"]);
    let DataValue = new Blob([DT],{type:'text/plain'});
    if(DownloadValue != null)
    {
        window.URL.revokeObjectURL(DownloadValue);
    }
    DownloadValue = window.URL.createObjectURL(DataValue);
    document.getElementById("BannerTop").children[1].children[2].download = "Script_For_"+Json["DATASCRIPT-NAME"]+".js";
    document.getElementById("BannerTop").children[1].children[2].href = DownloadValue;
    document.getElementById("BannerTop").children[1].children[2].style = "display:inline;";
}
function startEdit()
{
    if(EditorMode)
    {
        document.getElementById("BannerTop").children[1].children[0].innerHTML = "Editor Mode:off";
        EditorMode = false;
        document.getElementById("BannerTop").children[1].children[1].style = "display:none";
        document.getElementById("BannerTop").children[1].children[2].style = "display:none";
        document.getElementById("BannerTop").children[1].children[3].style = "display:none";
        document.getElementById("BannerTop").children[1].children[4].style = "display:none";
        //document.getElementById("BannerTop").children[1].children[5].style = "display:none";
        document.getElementById("BannerTop").children[1].children[7].style = "display:inline";
        document.getElementById("BannerTop").children[1].children[6].style = "display:none";

    }
    else
    {
        document.getElementById("BannerTop").children[1].children[0].innerHTML = "Editor Mode:on";
        EditorMode = true;
        document.getElementById("BannerTop").children[1].children[1].style = "display:inline";
        document.getElementById("BannerTop").children[1].children[3].style = "display:inline";
        document.getElementById("BannerTop").children[1].children[4].style = "display:inline";
       // document.getElementById("BannerTop").children[1].children[5].style = "display:inline";
        document.getElementById("BannerTop").children[1].children[7].style = "display:none";
        document.getElementById("BannerTop").children[1].children[6].style = "display:inline";
    }
}