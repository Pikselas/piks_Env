var counter = 0;
function loadImage()
{
    document.getElementById("middle").children[1].innerHTML += '<img onclick = "SetVideoPos(event)" src = "'+Json["IMAGE"][counter]+'" id = "'+Json["IMAGE_id"]+counter+'" title = "'+Json["IMAGE_id"]+counter+'"/>';
    counter += 1;
    if(counter < Json["IMAGE"].length)
    {
        setTimeout(loadImage(),1);
        //console.log(counter,Json["IMAGE"].length);
    }
}
function load()
{
    document.getElementById("BannerTop").children[0].src = Json["BANNER-TOP"];
    document.getElementById("BannerBottom").children[0].src = Json["BANNER-BOTTOM"];
    document.getElementById("middle").children[0].src = Json["VIDEO"]; 
    document.getElementById("middle").children[0].poster = Json["VIDEO-POSTER"];
    document.getElementById("tl").innerHTML = Json["DATASCRIPT-NAME"];
}
function PushToTime()
{
    let TotalImage = Json["IMAGE"].length;
    if(SyncImV["IMAGE_ID"].length == 0)
    {
        let VideoLength = document.getElementById("middle").children[0].duration;
        let TimePerImage = VideoLength / TotalImage;
        let j = TimePerImage;
        //console.log(VideoLength+" "+TotalImage);
        for(let i = 0;i<TotalImage;i+=1)
        {
            SyncImV["IMAGE_ID"].push(Json["IMAGE_id"]+i);
            SyncImV["VIDEO_TIME"].push(j);
            j += TimePerImage;
        }
    }
}
document.getElementById("BannerTop").children[1].children[5].children[1].innerHTML = QuickView["FROM-TIME"].length;
load();
loadImage();
setTimeout(PushToTime,1);