var Json = {
    "BANNER-TOP":"",
    "BANNER-BOTTOM":"",
    "VIDEO" :"",
    "IMAGE" :[
            ],
    "IMAGE_id":"",
    "DATASCRIPT-NAME":"",
"VIDEO-POSTER":""
};
var SyncImV = {"IMAGE_ID":[],
"VIDEO_TIME":[]};
var QuickView ={"FROM-TIME":[[1]],
"TO-TIME":[[1]]}