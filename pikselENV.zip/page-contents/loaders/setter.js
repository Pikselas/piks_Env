var counter = 0;
var timed = setTimeout(ChangeScreen,7000,0);
var changedScreen = false;
var FullScreen = false
function loadImage()
{
    document.getElementById("middle").children[1].innerHTML += '<img onclick = "SetVideoPos(event)" src = "'+Json["IMAGE"][counter]+'" id = "'+Json["IMAGE_id"]+counter+'" title = "'+Json["IMAGE_id"]+counter+'"/>';
    counter += 1;
    if(counter < Json["IMAGE"].length)
    {
        setTimeout(loadImage(),1);
        //console.log(counter,Json["IMAGE"].length);
    }
}
function load()
{
    document.getElementById("BannerTop").children[0].src = Json["BANNER-TOP"];
    document.getElementById("BannerBottom").children[0].src = Json["BANNER-BOTTOM"];
    document.getElementById("middle").children[0].src = Json["VIDEO"]; 
    document.getElementById("middle").children[0].poster = Json["VIDEO-POSTER"];
    document.getElementById("tl").innerHTML = Json["DATASCRIPT-NAME"];
}
function changeSize(Incrementer)
{
    let w = document.getElementById("middle").offsetWidth;
    let h = document.getElementById("middle").offsetHeight;
    document.getElementById("middle").children[0].height = Number(h);
    document.getElementById("middle").children[0].width = Number(w) * (Incrementer)/100;
    document.getElementById("middle").children[1].style.width = (100 - Incrementer)+'%';
}
function setSize()
{
    changeSize(Number(document.getElementById("SetSizer").value));
}
function ChangeScreen(type)
{
    if(!EditorMode)
    {
    if(type == 0)
    {
        document.getElementById("middle").style.height = "100%";
        document.getElementById("middle").style.top = "0%";
        document.getElementById("middle").style.cursor = "none";
        changedScreen = true;
        setSize();
    }
    else
    {
        document.getElementById("middle").style.height = "87%";
        document.getElementById("middle").style.top = "6.5%";
        document.getElementById("middle").style.cursor = "default";
        changedScreen = false;
        setSize();
    }
    }
}
function PushToTime()
{
    let TotalImage = Json["IMAGE"].length;
    if(SyncImV["IMAGE_ID"].length == 0)
    {
        let VideoLength = document.getElementById("middle").children[0].duration;
        let TimePerImage = VideoLength / TotalImage;
        let j = TimePerImage;
        //console.log(VideoLength+" "+TotalImage);
        for(let i = 0;i<TotalImage;i+=1)
        {
            SyncImV["IMAGE_ID"].push(Json["IMAGE_id"]+i);
            SyncImV["VIDEO_TIME"].push(j);
            j += TimePerImage;
        }
    }
}
function Pushfunction()
{
setTimeout(()=>{
    if(document.getElementById("middle").children[0].duration > 0 )
    {
        PushToTime();
        alert("Loaded completely");
    }
    else
    {
        Pushfunction();
    }
},1)
}
function SetFocus(stl,opacityLevel)
{
    switch(stl)
    {
        case 0:
            document.getElementById("middle").children[0].style.opacity = opacityLevel;
            document.getElementById("middle").children[1].style.opacity = 1;
            break;
        case 1:
            document.getElementById("middle").children[1].style.opacity = opacityLevel;
            document.getElementById("middle").children[0].style.opacity = 1;
            break;
        default:
            document.getElementById("middle").children[0].style.opacity = opacityLevel;
            document.getElementById("middle").children[1].style.opacity = opacityLevel;
            break;
    }
    document.getElementById("BannerTop").style.opacity = opacityLevel;
    document.getElementById("BannerBottom").style.opacity = opacityLevel;
}
function setscreen() {
    let el = document.fullscreenElement;
    let elem = document.getElementById("MainSection");
    if(el ==null)
    {
  if (elem.requestFullscreen) {
    elem.requestFullscreen();
  } else if (elem.webkitRequestFullscreen) { /* Safari */
    elem.webkitRequestFullscreen();
  } else if (elem.msRequestFullscreen) { /* IE11 */
    elem.msRequestFullscreen();
  }
  document.getElementById("BannerTop").children[1].children[8].innerHTML = "[@_@]";
    }
else
{
    if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if (document.webkitExitFullscreen) { /* Safari */
        document.webkitExitFullscreen();
      } else if (document.msExitFullscreen) { /* IE11 */
        document.msExitFullscreen();
      }
      document.getElementById("BannerTop").children[1].children[8].innerHTML = "[*_*]";
}
  setTimeout(setSize,1000);
}


document.getElementById("BannerTop").children[1].children[5].children[1].innerHTML = QuickView["FROM-TIME"].length;
document.getElementById("middle").children[0].style = "background-image:url('"+Json["VIDEO-POSTER"]+"')";
load();
loadImage();
Pushfunction();
document.onmousemove = function()
{
    if(!EditorMode)
    {
    clearTimeout(timed);
    if(changedScreen)
    {
        ChangeScreen(1);
    }
    timed = setTimeout(ChangeScreen,10000,0);
    }
}